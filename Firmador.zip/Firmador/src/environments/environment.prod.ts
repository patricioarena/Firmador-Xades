export const environment = {
  production: true,
  API_URL: 'http://apps.fepba.gov.ar/Signature/'
};
